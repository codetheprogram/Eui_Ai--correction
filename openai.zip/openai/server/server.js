import express from 'express'
import * as dotenv from 'dotenv'
import cors from 'cors'
import  OpenAI  from 'openai'


dotenv.config()

const configuration = new OpenAI({
  apiKey: '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',
});

const openai = new OpenAI(configuration);

const app = express()
app.use(cors())
app.use(express.json())

app.get('/', async (req, res) => {
  res.status(200).send({
    message: 'Hello from CodeX!'
  })
})

app.post('/', async (req, res) => {
  try {
    const prompt = req.body.prompt;
  
    const response = await openai.completions.create({
      model: "gpt-3.5-turbo-instruct",
      prompt: `${prompt}`,
    //   messages: [
    //     { role: "developer", content: "You are a helpful assistant." },
    //     {
    //         role: "user",
    //         content: "Write a haiku about recursion in programming.",
    //     },
    // ],
      temperature: 0, 
      max_tokens: 4000,
      top_p: 1,
      frequency_penalty: 0,
      presence_penalty: 0 
    });

    res.status(200).send({
      bot: response.choices[0].text
    }); 

  } catch (error) {
    console.error(error)
    res.status(500).send(error || 'Something went wrong');
  }
})

app.listen(5000, () => console.log('AI server started on http://localhost:5000'))